using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;

public class SelectTechnologyPanel : MonoBehaviour
{
    public Button Button1;
    public Button Button2;
    public Button Button3;
    public TextMeshProUGUI TitleText;
    public TextAsset TechFile;

    private void Start()
    {
        this.gameObject.SetActive(false);

        foreach(string line in TechFile.text.Split('\n'))
        {
            Debug.Log(line);
        }

        Button1.GetComponentInChildren<TextMeshProUGUI>().text = "Technology 1";
        Button2.GetComponentInChildren<TextMeshProUGUI>().text = "Technology 2";
        Button3.GetComponentInChildren<TextMeshProUGUI>().text = "Technology 3";
    }
}
